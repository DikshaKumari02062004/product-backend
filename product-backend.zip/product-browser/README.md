# Product Browser — Backend

A backend for browsing ~200,000 products, newest first, with category
filtering and pagination that stays correct and fast even while data is
changing underneath the user.

Stack: **Node.js (Express) + PostgreSQL**.

---

## TL;DR — the core design decision

The brief is really a pagination-correctness problem disguised as a CRUD
task. The naive approach — `LIMIT / OFFSET` — fails both halves of the
requirement:

- **Correctness:** `OFFSET 5000` means "skip the first 5000 rows of the
  current result set." If rows are inserted above that window while a
  user is mid-scroll, every row's position shifts. The next `OFFSET`
  request then either re-shows a product the user already saw
  (duplicate) or skips one entirely (missed item).
- **Performance:** to satisfy `OFFSET 100000`, Postgres still has to walk
  and discard the first 100,000 matching rows on *every single request*.
  Page 1 is fast; page 4000 gets linearly slower.

The fix is **keyset (cursor) pagination**: instead of asking for "rows
100,000–100,029", the client says "give me rows older than the last one
I saw" — i.e. `WHERE (created_at, id) < (last_seen_created_at, last_seen_id)`.

- It's correct under concurrent writes: that predicate's meaning doesn't
  change when unrelated rows are inserted/updated elsewhere. Fifty new
  products appearing at the top simply have a `created_at` newer than
  the cursor, so they never intersect with pages the user already moved
  past. No duplicates, nothing skipped.
- It's fast at any depth: the predicate is answered directly by a
  `(created_at DESC, id DESC)` B-tree index with an index range scan —
  page 1 and page 4000 cost the same. Verified locally (see below):
  cursor lookup **0.09ms** vs. equivalent `OFFSET` lookup **18.9ms** at
  150,000 rows deep — and the gap widens with depth, since `OFFSET`'s
  cost grows linearly while the cursor's stays flat.

One more deliberate choice: sorting is by `created_at` (creation time),
not `updated_at`. Editing an existing product (price change, etc.) never
reshuffles the "newest first" feed — only genuinely new products move to
the top. That's what keeps an in-progress browsing session visually
stable while edits happen elsewhere, rather than rows jumping around the
list as they're touched.

---

## Schema & indexes (`db/schema.sql`)

```sql
CREATE TABLE products (
  id          BIGSERIAL PRIMARY KEY,
  name        TEXT           NOT NULL,
  category    TEXT           NOT NULL,
  price       NUMERIC(10,2)  NOT NULL,
  created_at  TIMESTAMPTZ    NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ    NOT NULL DEFAULT now()
);

CREATE INDEX idx_products_created_id          ON products (created_at DESC, id DESC);
CREATE INDEX idx_products_category_created_id ON products (category, created_at DESC, id DESC);
CREATE INDEX idx_products_category            ON products (category);
```

`id` (a `BIGSERIAL`) is the unique identifier *and* doubles as a
deterministic tie-breaker for the sort. Since the seed data spreads
`created_at` randomly over the last year, ties on the exact timestamp are
effectively impossible at 200k rows, but the composite key keeps
pagination strictly correct even if they happened.

The category-scoped composite index means filtered browsing
(`?category=Electronics`) is just as fast as unfiltered browsing — same
index-range-scan shape, just with an extra equality predicate up front.

---

## API

### `GET /api/products`

| param      | required | description                                            |
|------------|----------|--------------------------------------------------------|
| `limit`    | no       | page size, default 24, max 100                         |
| `category` | no       | exact match filter                                      |
| `cursor`   | no       | opaque token from the previous response's `next_cursor` |

```json
{
  "data": [ { "id": "...", "name": "...", "category": "...", "price": "...", "created_at": "...", "updated_at": "..." }, ... ],
  "page_size": 24,
  "next_cursor": "eyJjcmVhdGVkX2F0Ijoi...",
  "has_more": true
}
```

Omit `cursor` for page 1; pass back whatever `next_cursor` you were given
to get the next page. Treat the cursor as opaque — it's a base64
encoding of `{created_at, id}`, but that shape isn't a public contract.
`has_more: false` / `next_cursor: null` means you've reached the end.

### `GET /api/categories`

Returns each distinct category with its product count, for populating a
filter dropdown:

```json
{ "data": [ { "category": "Electronics", "count": 20195 }, ... ] }
```

### `GET /api/health`

Basic liveness/DB-connectivity check.

---

## The seed script (`scripts/seed.js`)

Generates 200,000 (configurable) products **without looping 200,000 times
in JavaScript**. A per-row JS loop means 200,000 round trips (or at best
200,000 parameter bindings) — slow, and not how you'd want this to scale
to millions. Instead, generation is pushed down into Postgres using
`generate_series`, so a single SQL statement asks the database to both
*generate* and *insert* an entire batch of rows in one round trip. The
script just loops over batches (default 20,000 rows/statement, purely to
keep each statement small and print progress — Postgres could handle all
200,000 in one statement just fine).

```
npm run seed            # 200,000 products (default)
node scripts/seed.js 50000   # custom count
```

Locally, seeding 200,000 rows (including building both indexes) takes
**~3 seconds**.

One real bug worth calling out because it's a sneaky correctness trap:
the first draft of this script computed `created_at` inside a
`CROSS JOIN LATERAL` subquery that didn't reference the outer
`generate_series` row. Postgres's planner treated it as uncorrelated and
evaluated `random()` **once per batch** instead of once per row — so all
20,000 rows in a batch silently got the *same* `created_at`. That's
exactly the kind of tie that breaks keyset pagination (rows behind a
shared sort-key value get skipped or duplicated at page boundaries). The
fix was to force a real correlation to the outer row
(`+ (gs - gs) * interval '1 second'`, a value-wise no-op) so Postgres
re-evaluates per row. After the fix: 200,000 rows → 200,000 distinct
`created_at` values, verified via `verify-correctness.js`.

---

## Proving the concurrency requirement (`scripts/verify-correctness.js`)

This is an end-to-end test against the **running HTTP API**, not just the
DB:

1. Snapshot every product id that exists before browsing starts.
2. Page through `GET /api/products` from page 1 using `next_cursor`,
   with a small delay between requests (mimics a real scrolling user).
3. Partway through (after a few pages), fire 30 inserts + 20 updates —
   the "50 products added/updated while someone is browsing" scenario —
   concurrently with the ongoing pagination requests.
4. After pagination finishes, assert:
   - **zero duplicates** across all pages returned,
   - **zero missing** products from the original snapshot,
   - **zero leakage** of the newly-inserted products into this browsing
     session (they're newer than the active cursor, so a stable session
     correctly excludes them — they'll show up on a fresh visit to page 1).

```
npm run seed             # if you haven't already
npm start                 # in one terminal
npm run verify-correctness   # in another
```

Sample output against the seeded 200k dataset:

```
Snapshot: 200000 products exist before browsing starts.
>>> Triggering 30 inserts + 20 updates CONCURRENTLY with ongoing pagination...
>>> Concurrent writes finished: { inserted: 30, updated: 20 }
Paged through 2001 pages, 200000 total rows returned.
[PASS] Duplicates seen during browsing: 0
[PASS] Original products missing from results: 0
[PASS] Newly-inserted products that leaked into results: 0 (expected 0)
OVERALL: PASS ✅
```

You can also run `npm run simulate-writes` standalone any time to inject
50 random writes against a live database, e.g. while manually clicking
through the bonus UI in a browser.

---

## Performance verification

```sql
EXPLAIN ANALYZE
SELECT id FROM products
WHERE (created_at, id) < ('2025-08-24 07:05:07.689406+00', 150000)
ORDER BY created_at DESC, id DESC
LIMIT 24;
-- Index Only Scan using idx_products_created_id, Execution Time: 0.093 ms

EXPLAIN ANALYZE
SELECT id FROM products
ORDER BY created_at DESC, id DESC
OFFSET 150000 LIMIT 24;
-- Index Only Scan + discard 150,000 rows, Execution Time: 18.860 ms
```

200x faster at this depth, and the cursor query's cost doesn't grow as
you page further — it's the same index seek whether it's page 2 or page
8000.

---

## Running locally

```bash
cp .env.example .env       # point DATABASE_URL at your Postgres
npm install
npm run seed                # creates schema + 200,000 products
npm start                   # http://localhost:3000
```

Open `http://localhost:3000` for the bonus UI (infinite-scroll grid with
a category filter), or hit the JSON API directly at `/api/products`.

## Deploying for free (no credit card)

**Database — [Neon](https://neon.tech):**
1. Create a free project → copy the connection string it gives you
   (already includes `?sslmode=require`).
2. Put it in `DATABASE_URL`.
3. Run `npm run seed` once, locally, pointed at that connection string,
   to create the schema and the 200k products.

**Backend — [Render](https://render.com):**
1. Push this repo to GitHub.
2. New → Web Service → connect the repo.
3. Build command: `npm install`. Start command: `npm start`.
4. Add an environment variable `DATABASE_URL` with your Neon connection
   string. Render's free tier needs no credit card.
5. Deploy — the bonus UI is served from the same service at `/`.

---

## Project layout

```
db/schema.sql                  table + index definitions
scripts/seed.js                 set-based 200k product generator
scripts/simulate-writes.js      injects 50 concurrent inserts/updates
scripts/verify-correctness.js   end-to-end no-dup/no-miss proof
src/server.js                   Express app
src/db.js                       pg connection pool
src/routes/products.js          cursor-paginated /api/products, /api/categories
public/                         bonus UI (vanilla HTML/CSS/JS, infinite scroll)
```
