const express = require('express');
const pool = require('../db');

const router = express.Router();

const DEFAULT_LIMIT = 24;
const MAX_LIMIT = 100;

/**
 * Cursor encoding/decoding.
 *
 * The cursor is just an opaque, base64-encoded JSON blob carrying the
 * (created_at, id) of the LAST row the client has already seen. The
 * client should treat it as an opaque token -- we don't promise its
 * internal shape is stable.
 */
function encodeCursor(row) {
  const payload = JSON.stringify({ created_at: row.created_at, id: row.id });
  return Buffer.from(payload, 'utf8').toString('base64url');
}

function decodeCursor(cursor) {
  try {
    const json = Buffer.from(cursor, 'base64url').toString('utf8');
    const obj = JSON.parse(json);
    if (!obj.created_at || !obj.id) return null;
    return obj;
  } catch {
    return null;
  }
}

/**
 * GET /api/products
 *
 * Query params:
 *   category  - optional, exact match filter
 *   limit     - page size (default 24, max 100)
 *   cursor    - opaque cursor from a previous response's `next_cursor`
 *               (omit for the first page)
 *
 * Why cursor (keyset) pagination instead of OFFSET/LIMIT:
 *
 * 1. CORRECTNESS under concurrent writes: OFFSET pagination identifies a
 *    page by *position* ("skip 5000 rows"). If rows are inserted above
 *    that position while the user is browsing, every row's position
 *    shifts, so the next OFFSET-based page either re-shows a row the user
 *    already saw (duplicate) or skips one entirely (missed item). Cursor
 *    pagination instead says "give me rows strictly older than the last
 *    one I saw" (`(created_at, id) < (cursor.created_at, cursor.id)`).
 *    That predicate's meaning doesn't change when unrelated rows are
 *    inserted or updated elsewhere in the table, including 50 brand-new
 *    products appearing at the very top (they all sort newer than the
 *    cursor, so they simply never intersect with pages the user has
 *    already moved past). The one edge case this can't fix -- a row
 *    being deleted out from under a page that's already been fetched --
 *    isn't asked for here (no deletes in this task), and even then it
 *    would only ever cause a "missed row", never a duplicate.
 *
 * 2. PERFORMANCE: OFFSET 100000 forces Postgres to walk and discard the
 *    first 100,000 matching rows on every request -- it gets slower the
 *    deeper you page. The keyset predicate above is answered directly by
 *    the (created_at DESC, id DESC) index with an index range scan, so
 *    page 1 and page 4000 cost the same.
 *
 * We deliberately sort by created_at (creation time), not updated_at.
 * That means editing an existing product never reshuffles the "newest
 * first" feed -- only genuinely new products move to the top. This is
 * what keeps an in-progress browse session stable while edits happen
 * elsewhere.
 */
router.get('/products', async (req, res) => {
  try {
    const limit = Math.min(
      MAX_LIMIT,
      Math.max(1, parseInt(req.query.limit, 10) || DEFAULT_LIMIT)
    );
    const { category } = req.query;
    const cursor = req.query.cursor ? decodeCursor(req.query.cursor) : null;

    if (req.query.cursor && !cursor) {
      return res.status(400).json({ error: 'Invalid cursor' });
    }

    const params = [];
    const where = [];

    if (category) {
      params.push(category);
      where.push(`category = $${params.length}`);
    }

    if (cursor) {
      params.push(cursor.created_at);
      params.push(cursor.id);
      where.push(`(created_at, id) < ($${params.length - 1}::timestamptz, $${params.length}::bigint)`);
    }

    params.push(limit);
    const limitParamIdx = params.length;

    const sql = `
      SELECT id, name, category, price, created_at, updated_at
      FROM products
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY created_at DESC, id DESC
      LIMIT $${limitParamIdx}
    `;

    const { rows } = await pool.query(sql, params);

    const next_cursor = rows.length === limit ? encodeCursor(rows[rows.length - 1]) : null;

    res.json({
      data: rows,
      page_size: rows.length,
      next_cursor,
      has_more: next_cursor !== null,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/categories - distinct categories for a filter dropdown.
router.get('/categories', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT category, count(*)::int AS count
       FROM products
       GROUP BY category
       ORDER BY category ASC`
    );
    res.json({ data: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
