require('dotenv').config();
const { Pool } = require('pg');
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: /localhost|127\.0\.0\.1/.test(process.env.DATABASE_URL || '')
    ? false
    : { rejectUnauthorized: false },
  max: 10,
});
pool.on('error', (err) => {
  console.error('Unexpected PG pool error', err);
});
module.exports = pool;
