const grid = document.getElementById('grid');
const statusEl = document.getElementById('status');
const categoryFilter = document.getElementById('categoryFilter');
const totalCountEl = document.getElementById('totalCount');
const sentinel = document.getElementById('sentinel');

let cursor = null;
let loading = false;
let exhausted = false;
let currentCategory = '';

function fmtPrice(p) {
  return '₹' + Number(p).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtDate(iso) {
  return new Date(iso).toLocaleString();
}

function renderCard(p) {
  const el = document.createElement('div');
  el.className = 'card';
  el.innerHTML = `
    <div class="category">${p.category}</div>
    <div class="name">${p.name}</div>
    <div class="price">${fmtPrice(p.price)}</div>
    <div class="meta">Created ${fmtDate(p.created_at)}</div>
  `;
  return el;
}

async function loadMore() {
  if (loading || exhausted) return;
  loading = true;
  statusEl.textContent = 'Loading...';

  const url = new URL('/api/products', window.location.origin);
  url.searchParams.set('limit', 30);
  if (cursor) url.searchParams.set('cursor', cursor);
  if (currentCategory) url.searchParams.set('category', currentCategory);

  try {
    const res = await fetch(url);
    const json = await res.json();

    for (const product of json.data) {
      grid.appendChild(renderCard(product));
    }

    cursor = json.next_cursor;
    exhausted = !json.has_more;
    statusEl.textContent = exhausted ? 'You have reached the end.' : '';
  } catch (err) {
    statusEl.textContent = 'Failed to load products.';
    console.error(err);
  } finally {
    loading = false;
  }
}

function resetAndLoad() {
  grid.innerHTML = '';
  cursor = null;
  exhausted = false;
  loadMore();
}

async function loadCategories() {
  const res = await fetch('/api/categories');
  const json = await res.json();
  let total = 0;
  for (const row of json.data) {
    total += row.count;
    const opt = document.createElement('option');
    opt.value = row.category;
    opt.textContent = `${row.category} (${row.count.toLocaleString()})`;
    categoryFilter.appendChild(opt);
  }
  totalCountEl.textContent = `${total.toLocaleString()} products`;
}

categoryFilter.addEventListener('change', () => {
  currentCategory = categoryFilter.value;
  resetAndLoad();
});

const observer = new IntersectionObserver((entries) => {
  if (entries[0].isIntersecting) loadMore();
});
observer.observe(sentinel);

loadCategories();
loadMore();
