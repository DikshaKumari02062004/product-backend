require('dotenv').config();
const pool = require('../src/db');
const CATEGORIES = [
  'Electronics', 'Apparel', 'Home & Kitchen', 'Books', 'Beauty',
  'Sports & Outdoors', 'Toys & Games', 'Grocery', 'Automotive', 'Office Supplies',
];
async function simulateWrites({ inserts = 30, updates = 20 } = {}) {
  const client = await pool.connect();
  try {
    for (let i = 0; i < inserts; i++) {
      const category = CATEGORIES[Math.floor(Math.random() * CATEGORIES.length)];
      const price = (Math.random() * 4990 + 10).toFixed(2);
      await client.query(
        `INSERT INTO products (name, category, price, created_at, updated_at)
         VALUES ($1, $2, $3, now(), now())`,
        [`New Arrival ${Date.now()}-${i}`, category, price]
      );
    }
    const { rows: sample } = await client.query(
      `SELECT id FROM products ORDER BY random() LIMIT $1`,
      [updates]
    );
    for (const row of sample) {
      await client.query(
        `UPDATE products SET price = round((random()*4990+10)::numeric,2), updated_at = now() WHERE id = $1`,
        [row.id]
      );
    }
    return { inserted: inserts, updated: sample.length };
  } finally {
    client.release();
  }
}
if (require.main === module) {
  simulateWrites()
    .then((result) => {
      console.log('Simulated concurrent writes:', result);
      return pool.end();
    })
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}
module.exports = { simulateWrites };
