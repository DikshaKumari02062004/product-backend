require('dotenv').config();
const fs = require('fs');
const path = require('path');
const pool = require('../src/db');
const TOTAL = parseInt(process.argv[2] || '200000', 10);
const BATCH_SIZE = 20000;
const CATEGORIES = [
  'Electronics', 'Apparel', 'Home & Kitchen', 'Books', 'Beauty',
  'Sports & Outdoors', 'Toys & Games', 'Grocery', 'Automotive', 'Office Supplies',
];
async function applySchema(client) {
  const schemaSql = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
  await client.query(schemaSql);
}
async function seed() {
  const client = await pool.connect();
  const start = Date.now();
  try {
    console.log('Applying schema (tables + indexes)...');
    await applySchema(client);
    console.log(`Seeding ${TOTAL} products in batches of ${BATCH_SIZE}...`);
    for (let inserted = 0; inserted < TOTAL; inserted += BATCH_SIZE) {
      const n = Math.min(BATCH_SIZE, TOTAL - inserted);
      await client.query(
        `
        INSERT INTO products (name, category, price, created_at, updated_at)
        SELECT
          'Product ' || (gs + $1)::text || ' - ' ||
            (ARRAY['Pro','Lite','Max','Plus','Mini','Ultra','Standard','Classic'])
              [1 + floor(random() * 8)::int],
          ($3::text[])[1 + floor(random() * array_length($3::text[], 1))::int],
          round((random() * 4990 + 10)::numeric, 2),
          c.created_at,
          c.created_at + (random() * interval '10 days')   -- updated_at >= created_at
        FROM generate_series(1, $2) AS gs
        CROSS JOIN LATERAL (
          -- The "+ (gs - gs) * interval '1 second'" is a no-op value-wise,
          -- but it correlates this subquery to the gs column, which forces
          -- Postgres to re-evaluate random() for every single output row
          -- instead of (incorrectly) caching/reusing one random value for
          -- the whole batch. Without it, all 20,000 rows in a batch can
          -- end up sharing the exact same created_at, which silently
          -- breaks keyset pagination (many rows tie on the sort key).
          SELECT now() - (random() * interval '365 days') + (gs - gs) * interval '1 second' AS created_at
        ) c
        `,
        [inserted, n, CATEGORIES]
      );
      console.log(`  inserted ${Math.min(inserted + BATCH_SIZE, TOTAL)} / ${TOTAL}`);
    }
    const { rows } = await client.query('SELECT count(*)::int AS count FROM products');
    const seconds = ((Date.now() - start) / 1000).toFixed(2);
    console.log(`Done. products table now has ${rows[0].count} rows. Took ${seconds}s.`);
  } finally {
    client.release();
    await pool.end();
  }
}
seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
