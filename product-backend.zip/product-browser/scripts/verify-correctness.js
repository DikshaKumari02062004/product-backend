require('dotenv').config();
const pool = require('../src/db');
const { simulateWrites } = require('./simulate-writes');
const BASE_URL = process.env.VERIFY_BASE_URL || 'http://localhost:3000';
const PAGE_SIZE = 500; // smaller pages = more requests = more chances to interleave writes
const DELAY_MS = 15; // small delay between page fetches to widen the race window
async function fetchPage(cursor) {
  const url = new URL('/api/products', BASE_URL);
  url.searchParams.set('limit', PAGE_SIZE);
  if (cursor) url.searchParams.set('cursor', cursor);
  const res = await fetch(url);
  if (!res.ok) throw new Error(`API error ${res.status}`);
  return res.json();
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
async function main() {
  console.log(`Target API: ${BASE_URL}`);
  const { rows: before } = await pool.query('SELECT id FROM products');
  const snapshotIds = new Set(before.map((r) => String(r.id)));
  console.log(`Snapshot: ${snapshotIds.size} products exist before browsing starts.`);
  const seen = [];
  const seenSet = new Set();
  let duplicates = 0;
  let cursor = null;
  let page = 0;
  let writesTriggered = false;
  let writesResult = null;
  let writesPromise = null;
  do {
    const result = await fetchPage(cursor);
    page += 1;
    for (const row of result.data) {
      const id = String(row.id);
      if (seenSet.has(id)) duplicates += 1;
      seenSet.add(id);
      seen.push(id);
    }
    if (!writesTriggered && page === 3) {
      writesTriggered = true;
      console.log('>>> Triggering 30 inserts + 20 updates CONCURRENTLY with ongoing pagination...');
      writesPromise = simulateWrites({ inserts: 30, updates: 20 }).then((r) => {
        writesResult = r;
        console.log('>>> Concurrent writes finished:', r);
      });
    }
    cursor = result.next_cursor;
    await sleep(DELAY_MS);
  } while (cursor);
  if (writesPromise) await writesPromise;
  console.log(`Paged through ${page} pages, ${seen.length} total rows returned.`);
  const dupCheck = duplicates === 0;
  console.log(`[${dupCheck ? 'PASS' : 'FAIL'}] Duplicates seen during browsing: ${duplicates}`);
  let missing = 0;
  for (const id of snapshotIds) {
    if (!seenSet.has(id)) missing += 1;
  }
  const missingCheck = missing === 0;
  console.log(`[${missingCheck ? 'PASS' : 'FAIL'}] Original products missing from results: ${missing}`);
  let leaked = 0;
  for (const id of seenSet) {
    if (!snapshotIds.has(id)) leaked += 1;
  }
  const leakCheck = leaked === 0;
  console.log(
    `[${leakCheck ? 'PASS' : 'INFO'}] Newly-inserted products that leaked into results: ${leaked} ` +
      `(expected 0 -- they're newer than the browsing cursor)`
  );
  const allPass = dupCheck && missingCheck && leakCheck;
  console.log(`\nOVERALL: ${allPass ? 'PASS ✅' : 'FAIL ❌'}`);
  await pool.end();
  process.exit(allPass ? 0 : 1);
}
main().catch((err) => {
  console.error(err);
  process.exit(1);
});
